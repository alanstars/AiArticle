DROP TABLE IF EXISTS `#@__weapp_ai_article`;
DROP TABLE IF EXISTS `#@__weapp_ai_article_conf`;
DROP TABLE IF EXISTS `#@__weapp_ai_article_lists`;