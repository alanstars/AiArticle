<?php
return [
    'plugin_name' => 'AI Article Auto Update',
    'description' => 'AI automatically generates articles, updates automatically at regular intervals, and supports multiple languages.',
    // 其他需要翻译的文本
];
