<?php
return [
    'plugin_name' => 'Ai文章自动更新',
    'description' => 'Ai 自动生成文章，定时自动更新，支持多语言',
    // 其他需要翻译的文本
];
